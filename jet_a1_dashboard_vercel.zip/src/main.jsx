import React from 'react'
import ReactDOM from 'react-dom/client'
import JetA1Dashboard from './JetA1Dashboard'
ReactDOM.createRoot(document.getElementById('root')).render(<JetA1Dashboard />)